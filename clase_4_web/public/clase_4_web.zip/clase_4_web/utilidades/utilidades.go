package utilidades

import (
	"net/http"

	"github.com/gorilla/sessions"
	gomail "gopkg.in/gomail.v2"
)

var Frontend string = "templates/layout/frontend.html"

var Store = sessions.NewCookieStore([]byte("session-name"))

func RetornarLogin(request *http.Request) (string, string) {
	session, _ := Store.Get(request, "session-name")
	tamila_id := ""
	tamila_nombre := ""
	if session.Values["tamila_id"] != nil {
		tamila_id_t, _ := session.Values["tamila_id"].(string)
		tamila_id = tamila_id_t
	}
	if session.Values["tamila_nombre"] != nil {
		tamila_nombre_t, _ := session.Values["tamila_nombre"].(string)
		tamila_nombre = tamila_nombre_t
	}
	return tamila_id, tamila_nombre
}

func RetornarMensajesFlash(response http.ResponseWriter, request *http.Request) (string, string) {
	session, _ := Store.Get(request, "flash-session")

	fm := session.Flashes("css")
	session.Save(request, response)
	css_sesion := ""
	if len(fm) == 0 {
		css_sesion = ""
	} else {
		css_sesion = fm[0].(string)
	}
	fm2 := session.Flashes("mensaje")
	session.Save(request, response)
	css_mensaje := ""
	if len(fm2) == 0 {
		css_mensaje = ""
	} else {
		css_mensaje = fm2[0].(string)
	}
	return css_sesion, css_mensaje
}

func CrearMensajesFlash(response http.ResponseWriter, request *http.Request, css string, mensaje string) {
	session, err := Store.Get(request, "flash-session")
	if err != nil {
		http.Error(response, err.Error(), http.StatusInternalServerError)
		return
	}
	session.AddFlash(css, "css")
	session.AddFlash(mensaje, "mensaje")
	session.Save(request, response)
}
func EnviarCorreo() {
	msg := gomail.NewMessage()
	msg.SetHeader("From", "noreply@agendahoras.cl")
	msg.SetHeader("To", "peligrosamente@gmail.com")
	msg.SetHeader("Subject", "Curso de Golang")
	msg.SetBody("text/html", "<h1>Curso de Golang</h1><b>Este texto va en negritas</b><p>párrafo con otro texto</p>")
	msg.Attach("/media/tamila/tera/respaldo/cursos_tamila/curso_golang_udemy/clase_4_web/public/images/yoda.png")
	//ahora se debe configurar la conexión con el SMTP
	n := gomail.NewDialer("smtp.dreamhost.com", 587, "noreply@agendahoras.cl", "khdwJAXysB")

	if err := n.DialAndSend(msg); err != nil {
		panic(err)
	}

}
