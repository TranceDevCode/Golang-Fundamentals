package main

import (
	"clase_4_web/proteccion"
	"clase_4_web/rutas"
	"fmt"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/gorilla/mux"
	"github.com/joho/godotenv"
)

func main() {
	mux := mux.NewRouter()
	//rutas
	mux.HandleFunc("/", rutas.Home)
	mux.HandleFunc("/nosotros", rutas.Nosotros)
	mux.HandleFunc("/parametros/{id:.*}/{slug:.*}", rutas.Parametros)
	mux.HandleFunc("/parametros-querystring", rutas.ParametrosQueryString)
	mux.HandleFunc("/estructuras", rutas.Estructuras)

	mux.HandleFunc("/formularios", rutas.Formularios_get)
	mux.HandleFunc("/formularios-post", rutas.Formularios_post).Methods("POST")

	mux.HandleFunc("/formularios/upload", rutas.Formularios_upload)
	mux.HandleFunc("/formularios/upload-post", rutas.Formularios_upload_post).Methods("POST")

	mux.HandleFunc("/recursos-utiles", rutas.Recursos_utiles_get)
	mux.HandleFunc("/recursos-utiles/pdf", rutas.Recursos_utiles_pdf)
	mux.HandleFunc("/recursos-utiles/pdf-generar", rutas.Recursos_utiles_pdf_generar)
	mux.HandleFunc("/recursos-utiles/excel", rutas.Recursos_utiles_excel)
	mux.HandleFunc("/recursos-utiles/qr", rutas.Recursos_utiles_qr)
	mux.HandleFunc("/recursos-utiles/enviar-email", rutas.Recursos_utiles_enviar_email)

	mux.HandleFunc("/cliente-http", rutas.Cliente_http)
	mux.HandleFunc("/cliente-http/crear", rutas.Cliente_http_crear)
	mux.HandleFunc("/cliente-http/crear-post", rutas.Cliente_http_crear_post).Methods("POST")
	mux.HandleFunc("/cliente-http/editar/{id:.*}", rutas.Cliente_http_editar)
	mux.HandleFunc("/cliente-http/editar-post/{id:.*}", rutas.Cliente_http_editar_post).Methods("POST")
	mux.HandleFunc("/cliente-http/eliminar/{id:.*}", rutas.Cliente_http_eliminar)

	mux.HandleFunc("/mysql", rutas.Mysql_listar)
	mux.HandleFunc("/mysql/crear", rutas.Mysql_crear)
	mux.HandleFunc("/mysql/crear_post", rutas.Mysql_crear_post).Methods("POST")
	mux.HandleFunc("/mysql/editar/{id:.*}", rutas.Mysql_editar)
	mux.HandleFunc("/mysql/editar_post/{id:.*}", rutas.Mysql_editar_post).Methods("POST")
	mux.HandleFunc("/mysql/eliminar/{id:.*}", rutas.Mysql_eliminar)

	mux.HandleFunc("/seguridad/registro", rutas.Seguridad_registro)
	mux.HandleFunc("/seguridad/registro_post", rutas.Seguridad_registro_post).Methods("POST")
	mux.HandleFunc("/seguridad/login", rutas.Seguridad_login)
	mux.HandleFunc("/seguridad/login_post", rutas.Seguridad_login_post).Methods("POST")
	mux.HandleFunc("/seguridad/protegida", proteccion.Proteccion(rutas.Seguridad_protegida))
	mux.HandleFunc("/seguridad/logout", proteccion.Proteccion(rutas.Seguridad_logout))

	mux.HandleFunc("/pasarelas", rutas.Pasarelas_home)
	mux.HandleFunc("/pasarelas/webpay", rutas.Pasarelas_webpay)
	mux.HandleFunc("/pasarelas/webpay/respuesta", rutas.Pasarelas_webpay_respuesta)
	mux.HandleFunc("/pasarelas/paypal", rutas.Pasarelas_paypal)
	mux.HandleFunc("/pasarelas/paypal/respuesta", rutas.Pasarelas_paypal_respuesta)
	mux.HandleFunc("/pasarelas/paypal/cancelado", rutas.Pasarelas_paypal_cancelado)

	//archivos estáticos hacia mux
	s := http.StripPrefix("/public/", http.FileServer(http.Dir("./public/")))
	mux.PathPrefix("/public/").Handler(s)
	//error 404
	mux.NotFoundHandler = mux.NewRoute().HandlerFunc(rutas.Pagina404).GetHandler()
	//ejecución de servidor
	errorVariables := godotenv.Load()
	if errorVariables != nil {

		panic(errorVariables)
		return
	}
	server := &http.Server{
		Addr:         "192.168.1.88:" + os.Getenv("PORT"),
		Handler:      mux,
		WriteTimeout: 15 * time.Second,
		ReadTimeout:  15 * time.Second,
	}
	fmt.Println("corriendo servidor desde http://192.168.1.88:" + os.Getenv("PORT"))
	log.Fatal(server.ListenAndServe())
}

/*
func main() {
	//mux := http.NewServeMux()

	http.HandleFunc("/", func(response http.ResponseWriter, request *http.Request) {
		fmt.Fprintln(response, "hola mundo")
	})
	fmt.Println("corriendo servidor desde http://192.168.1.88:8081")
	log.Fatal(http.ListenAndServe("192.168.1.88:8081", nil))

}
*/
