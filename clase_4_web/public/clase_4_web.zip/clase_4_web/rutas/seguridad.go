package rutas

import (
	"clase_4_web/conectar"
	"clase_4_web/modelos"
	"clase_4_web/utilidades"
	"clase_4_web/validaciones"
	"fmt"
	"html/template"
	"net/http"
	"strconv"

	"golang.org/x/crypto/bcrypt"
)

func Seguridad_registro(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/seguridad/registro.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)
}
func Seguridad_registro_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""
	if len(request.FormValue("nombre")) == 0 {
		mensaje = mensaje + "El campo Nombre está vacío<br/> "
	}
	if len(request.FormValue("correo")) == 0 {
		mensaje = mensaje + " . El campo E-Mail está vacío "
	}

	if validaciones.Regex_correo.FindStringSubmatch(request.FormValue("correo")) == nil {
		mensaje = mensaje + " . El E-Mail ingresado no es válido "
	}
	if validaciones.ValidarPassword(request.FormValue("password")) == false {
		mensaje = mensaje + " . La contraseña debe tener al menos 1 número, una mayúscula, y un largo entre 6 y 20 caracteres "
	}
	if mensaje != "" {
		utilidades.CrearMensajesFlash(response, request, "danger", mensaje)
		http.Redirect(response, request, "/seguridad/registro", http.StatusSeeOther)
	}
	conectar.Conectar()
	sql := "insert into usuarios values(null, ?,?,?,?);"
	//generamos el hash de contraseña
	//p2gHNiENUw
	costo := 8
	bytes, _ := bcrypt.GenerateFromPassword([]byte(request.FormValue("password")), costo)
	_, err := conectar.Db.Exec(sql, request.FormValue("nombre"), request.FormValue("correo"), request.FormValue("telefono"), string(bytes))
	if err != nil {
		fmt.Fprintln(response, err)
	}
	utilidades.CrearMensajesFlash(response, request, "success", "Se creó el registro exitosamente")
	http.Redirect(response, request, "/seguridad/registro", http.StatusSeeOther)
}
func Seguridad_login(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/seguridad/login.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)
}
func Seguridad_login_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""

	if len(request.FormValue("correo")) == 0 {
		mensaje = mensaje + " . El campo E-Mail está vacío "
	}

	if validaciones.Regex_correo.FindStringSubmatch(request.FormValue("correo")) == nil {
		mensaje = mensaje + " . El E-Mail ingresado no es válido "
	}
	if validaciones.ValidarPassword(request.FormValue("password")) == false {
		mensaje = mensaje + " . La contraseña debe tener al menos 1 número, una mayúscula, y un largo entre 6 y 20 caracteres "
	}
	if mensaje != "" {
		utilidades.CrearMensajesFlash(response, request, "danger", mensaje)
		http.Redirect(response, request, "/seguridad/login", http.StatusSeeOther)
	}
	//conectamos a la BD
	conectar.Conectar()
	sql := "SELECT id, nombre, correo, telefono, password FROM usuarios where correo=?"
	datos, err := conectar.Db.Query(sql, request.FormValue("correo"))
	if err != nil {
		fmt.Println(err)
	}
	defer conectar.CerrarConexion()
	var dato modelos.Usuario
	for datos.Next() {
		errNext := datos.Scan(&dato.Id, &dato.Nombre, &dato.Correo, &dato.Telefono, &dato.Password)
		if errNext != nil {
			utilidades.CrearMensajesFlash(response, request, "danger", "Las credenciales son inválidas")
			http.Redirect(response, request, "/seguridad/login", http.StatusSeeOther)
		}
	}
	//comparar los hash
	passwordBytes := []byte(request.FormValue("password"))
	passwordBD := []byte(dato.Password)
	errPassword := bcrypt.CompareHashAndPassword(passwordBD, passwordBytes)
	if errPassword != nil {
		utilidades.CrearMensajesFlash(response, request, "danger", "Las credenciales son inválidas")
		http.Redirect(response, request, "/seguridad/login", http.StatusSeeOther)
	} else {
		session, _ := utilidades.Store.Get(request, "session-name")
		str := strconv.Itoa(dato.Id)
		session.Values["tamila_id"] = str
		session.Values["tamila_nombre"] = dato.Nombre
		err2 := session.Save(request, response)
		if err2 != nil {
			http.Error(response, err2.Error(), http.StatusInternalServerError)
			return
		}
		http.Redirect(response, request, "/seguridad/protegida", http.StatusSeeOther)
	}
}
func Seguridad_protegida(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/seguridad/protegida.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	tamila_id, tamila_nombre := utilidades.RetornarLogin(request)
	data := map[string]string{

		"css":           css_sesion,
		"mensaje":       css_mensaje,
		"tamila_id":     tamila_id,
		"tamila_nombre": tamila_nombre,
	}
	template.Execute(response, data)
}
func Seguridad_logout(response http.ResponseWriter, request *http.Request) {
	session, _ := utilidades.Store.Get(request, "session-name")
	session.Values["tamila_id"] = nil
	session.Values["tamila_nombre"] = nil
	err2 := session.Save(request, response)
	if err2 != nil {
		http.Error(response, err2.Error(), http.StatusInternalServerError)
		return
	}
	utilidades.CrearMensajesFlash(response, request, "primary", "Se ha cerrado tu sesión exitosamente")
	http.Redirect(response, request, "/seguridad/login", http.StatusSeeOther)
}
