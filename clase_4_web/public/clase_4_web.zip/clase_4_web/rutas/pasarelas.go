package rutas

import (
	"bytes"
	"clase_4_web/modelos"
	"clase_4_web/utilidades"
	"context"
	"encoding/json"
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
	paypal "github.com/plutov/paypal/v4"
)

func Pasarelas_home(response http.ResponseWriter, request *http.Request) {

	template := template.Must(template.ParseFiles("templates/pasarelas/home.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)

}
func Pasarelas_webpay(response http.ResponseWriter, request *http.Request) {

	template := template.Must(template.ParseFiles("templates/pasarelas/webpay.html", utilidades.Frontend))
	//comunicación a webpay
	errorVariables := godotenv.Load()
	if errorVariables != nil {

		fmt.Println(errorVariables)
		return
	}
	client := &http.Client{}
	datos := map[string]string{"buy_order": "ordenCompra12345678", "session_id": "ordenCompra12345678", "amount": "10000", "return_url": "http://192.168.1.88:8080/pasarelas/webpay/respuesta"}
	jsonValue, _ := json.Marshal(datos)
	req, err := http.NewRequest("POST", os.Getenv("WEBPAY_URL"), bytes.NewBuffer(jsonValue))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Tbk-Api-Key-Id", os.Getenv("WEBPAY_ID"))
	req.Header.Set("Tbk-Api-Key-Secret", os.Getenv("WEBPAY_SECRET"))
	if err != nil {
		fmt.Println(err)
	}
	reg, err2 := client.Do(req)
	defer reg.Body.Close()
	if err2 != nil {

	}
	body, err := ioutil.ReadAll(reg.Body)
	webpay := modelos.WebpayModel{}
	errJson := json.Unmarshal(body, &webpay)
	if errJson != nil {

	}
	//retorno
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
		"url":     webpay.Url,
		"token":   webpay.Token,
	}
	template.Execute(response, data)

}
func Pasarelas_webpay_respuesta(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/pasarelas/webpay_respuesta.html", utilidades.Frontend))
	//se realiza petición a webpay
	errorVariables := godotenv.Load()
	if errorVariables != nil {

		fmt.Println(errorVariables)
		return
	}
	client := &http.Client{}
	req, err := http.NewRequest("PUT", os.Getenv("WEBPAY_URL")+"/"+request.URL.Query().Get("token_ws"), nil)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Tbk-Api-Key-Id", os.Getenv("WEBPAY_ID"))
	req.Header.Set("Tbk-Api-Key-Secret", os.Getenv("WEBPAY_SECRET"))
	if err != nil {
		fmt.Println(err)
	}
	reg, err2 := client.Do(req)
	defer reg.Body.Close()
	if err2 != nil {

	}
	defer reg.Body.Close()
	//fmt.Println(reg.Body)
	body, err := ioutil.ReadAll(reg.Body)
	webpay := modelos.WebpayRespuestaModel{}

	errJson := json.Unmarshal(body, &webpay)
	if errJson != nil {

	}
	//fmt.Println(webpay.Card_detail["card_number"])
	//se retorna
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	amount := strconv.Itoa(webpay.Amount)
	data := map[string]string{

		"css":                 css_sesion,
		"mensaje":             css_mensaje,
		"token_ws":            request.URL.Query().Get("token_ws"),
		"vci":                 webpay.Vci,
		"amount":              amount,
		"status":              webpay.Status,
		"buy_order":           webpay.Buy_order,
		"session_id":          webpay.Session_id,
		"card_detail":         webpay.Card_detail["card_number"],
		"accounting_date":     webpay.Accounting_date,
		"transaction_date":    webpay.Transaction_date,
		"authorization_code":  webpay.Authorization_code,
		"payment_type_code":   webpay.Payment_type_code,
		"response_code":       webpay.Response_code,
		"installments_number": webpay.Installments_number,
	}
	template.Execute(response, data)
}
func retornarOrdenPaypal(token string) string {
	errorVariables := godotenv.Load()
	if errorVariables != nil {

		fmt.Println(errorVariables)

	}
	time := strings.Split(time.Now().String(), " ")
	orden := string(time[4][6:14])
	datos := `{
		"purchase_units": [
			{
				"amount": {
					"currency_code": "USD",
					"value": "10.00"
				},
				"reference_id": "orden_1"
			}
		],
		"intent": "CAPTURE",
		"payment_source": {
			"paypal": {
				"experience_context": {
					"payment_method_preference": "IMMEDIATE_PAYMENT_REQUIRED",
					"payment_method_selected": "PAYPAL",
					"brand_name": "Tamila",
					"locale": "es-ES",
					"landing_page": "LOGIN",
					"shipping_preference": "NO_SHIPPING",
					"user_action": "PAY_NOW",
					"return_url": "http://192.168.1.88:8080/pasarelas/paypal/respuesta",
					"cancel_url": "http://192.168.1.88:8080/pasarelas/paypal/cancelado"
				}
			}
		}
	}`
	byte_arr := []byte(datos)
	client := &http.Client{}
	req, err := http.NewRequest("POST", os.Getenv("PAYPAL_BASE_URI")+"/v2/checkout/orders", bytes.NewBuffer(byte_arr))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("PayPal-Request-Id", "orden_"+orden)
	if err != nil {

	}
	reg, err2 := client.Do(req)
	defer reg.Body.Close()
	if err2 != nil {

	}
	body, err := ioutil.ReadAll(reg.Body)
	paypal := modelos.PaypalOrderResponseModel{}
	errJson := json.Unmarshal(body, &paypal)
	if errJson != nil {

	}
	return paypal.Id
}
func retornarCapturaPaypal(token string, parametro string) string {
	errorVariables := godotenv.Load()
	if errorVariables != nil {

		fmt.Println(errorVariables)

	}
	client := &http.Client{}
	req, err := http.NewRequest("POST", os.Getenv("PAYPAL_BASE_URI")+"/v2/checkout/orders/"+parametro+"/capture", nil)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	if err != nil {
		fmt.Println(err)
	}
	reg, err2 := client.Do(req)
	defer reg.Body.Close()
	if err2 != nil {

	}
	defer reg.Body.Close()
	//fmt.Println(reg.Status)
	if reg.Status == "422 Unprocessable Entity" {

		return "mal"
	} else {

		return "bien"
	}

}
func retornarTokenPaypal() string {
	c, _ := paypal.NewClient(os.Getenv("PAYPAL_CLIENT_ID"), os.Getenv("PAYPAL_CLIENT_SECRET"), paypal.APIBaseSandBox)
	c.SetLog(os.Stdout) // Set log to terminal stdout

	accessToken, _ := c.GetAccessToken(context.Background())
	return accessToken.Token
}
func Pasarelas_paypal(response http.ResponseWriter, request *http.Request) {

	template := template.Must(template.ParseFiles("templates/pasarelas/paypal.html", utilidades.Frontend))
	token := retornarTokenPaypal()
	orden := retornarOrdenPaypal(token)
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
		"token":   token,
		"orden":   orden,
	}
	template.Execute(response, data)
}
func Pasarelas_paypal_respuesta(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/pasarelas/paypal_respuesta.html", utilidades.Frontend))
	//captura
	token := retornarTokenPaypal()
	estado_paypal := retornarCapturaPaypal(token, request.URL.Query().Get("token"))

	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":           css_sesion,
		"mensaje":       css_mensaje,
		"token":         request.URL.Query().Get("token"),
		"estado_paypal": estado_paypal,
	}
	template.Execute(response, data)
}
func Pasarelas_paypal_cancelado(response http.ResponseWriter, request *http.Request) {

	template := template.Must(template.ParseFiles("templates/pasarelas/paypal_cancelado.html", utilidades.Frontend))
	//hacemos la petición

	//retornamos
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
		"token":   request.URL.Query().Get("token"),
	}
	template.Execute(response, data)

}
