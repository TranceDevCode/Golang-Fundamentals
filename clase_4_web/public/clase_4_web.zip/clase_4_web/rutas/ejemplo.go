package rutas

import (
	"clase_4_web/utilidades"
	"html/template"
	"net/http"

	"github.com/gorilla/mux"
)

func Home(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/ejemplo/home.html", utilidades.Frontend))
	template.Execute(response, nil)
	/*
		template, err := template.ParseFiles("templates/ejemplo/home.html", "templates/layout/frontend.html")
		if err != nil {
			panic(err)
		} else {
			template.Execute(response, nil)
		}
	*/
}
func Pagina404(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/ejemplo/404.html", utilidades.Frontend))
	template.Execute(response, nil)

}
func Nosotros(response http.ResponseWriter, request *http.Request) {
	template, err := template.ParseFiles("templates/ejemplo/nosotros.html", "templates/layout/frontend.html")
	if err != nil {
		panic(err)
	} else {
		template.Execute(response, nil)
	}
}
func Parametros(response http.ResponseWriter, request *http.Request) {
	template, err := template.ParseFiles("templates/ejemplo/parametros.html", "templates/layout/frontend.html")
	vars := mux.Vars(request)
	texto := "mi muñeca me habló"
	data := map[string]string{
		"id":    vars["id"],
		"slug":  vars["slug"],
		"texto": texto,
	}
	if err != nil {
		panic(err)
	} else {
		template.Execute(response, data)
	}
}
func ParametrosQueryString(response http.ResponseWriter, request *http.Request) {
	template, err := template.ParseFiles("templates/ejemplo/parametros_querystring.html", "templates/layout/frontend.html")
	data := map[string]string{
		"id":   request.URL.Query().Get("id"),
		"slug": request.URL.Query().Get("slug"),
	}
	if err != nil {
		panic(err)
	} else {
		template.Execute(response, data)
	}
}

type Habilidad struct {
	Nombre string
}
type Datos struct {
	Nombre      string
	Edad        int
	Perfil      int
	Habilidades []Habilidad
}

func Estructuras(response http.ResponseWriter, request *http.Request) {

	template, _ := template.ParseFiles("templates/ejemplo/estructuras.html", "templates/layout/frontend.html")
	habilidad1 := Habilidad{"Inteligencia"}
	habilidad2 := Habilidad{"Videojuegos"}
	habilidad3 := Habilidad{"Programación"}
	habilidad4 := Habilidad{"Canto"}
	habilidades := []Habilidad{habilidad1, habilidad2, habilidad3, habilidad4}
	template.Execute(response, Datos{"César Cancino", 42, 1, habilidades})

	/*
		template, err := template.ParseFiles("templates/ejemplo/estructuras.html")
			if err != nil {
				panic(err)
			} else {
				template.Execute(response, Datos{"César Cancino", 42, 1})
			}
	*/
}

/*
	func Home(response http.ResponseWriter, request *http.Request) {
		fmt.Fprintln(response, "hola mundo desde Golang con ñandú")
	}

	func Nosotros(response http.ResponseWriter, request *http.Request) {
		fmt.Println("algo desde la terminal")
		fmt.Fprintln(response, "página sobre nosotros con ñandú")
	}

func Parametros(response http.ResponseWriter, request *http.Request) {
	vars := mux.Vars(request)
	fmt.Fprintln(response, "ID = "+vars["id"]+" | SLUG="+vars["slug"])
}
func ParametrosQueryString(response http.ResponseWriter, request *http.Request) {
	fmt.Fprintln(response, request.URL)
	fmt.Fprintln(response, request.URL.RawQuery)
	fmt.Fprintln(response, request.URL.Query())
	fmt.Fprintln(response, request.URL.Query().Get("id"))
	fmt.Fprintln(response, request.URL.Query().Get("slug"))
	id := request.URL.Query().Get("id")
	slug := request.URL.Query().Get("slug")
	fmt.Fprintln(response, "-------------------------------------")
	fmt.Fprintln(response, "id= %s | slug = %s", id, slug)
}
*/
