package rutas

import (
	"bytes"
	"clase_4_web/modelos"
	"clase_4_web/utilidades"
	"encoding/json"
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"

	"github.com/gorilla/mux"
)

var Token string = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MzYsImlhdCI6MTY4MzE1NTM1NiwiZXhwIjoxNjg1NzQ3MzU2fQ.eEZZHIqiM5FpR8ZwK3jPd-qT367epSK5qjoHU9f7r1I"

func Cliente_http(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/cliente_http/home.html", utilidades.Frontend))
	//nos conectamos a la API
	client := &http.Client{}
	req, err := http.NewRequest("GET", "https://www.api.tamila.cl/api/categorias", nil)
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Set("Authorization", Token)
	reg, _ := client.Do(req)
	defer reg.Body.Close()
	fmt.Println(reg.Status)
	//convertimos la información a un slice
	body, err := ioutil.ReadAll(reg.Body)
	datos := modelos.Categorias{}
	errJson := json.Unmarshal(body, &datos)
	if errJson != nil {

	}

	//retorno
	//css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]modelos.Categorias{
		"datos": datos,
	}
	template.Execute(response, data)

}
func Cliente_http_crear(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/cliente_http/crear.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)
}
func Cliente_http_crear_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""
	if len(request.FormValue("nombre")) == 0 {
		mensaje = mensaje + "El campo Nombre está vacío. "
	}
	if mensaje != "" {

		utilidades.CrearMensajesFlash(response, request, "danger", mensaje)
		http.Redirect(response, request, "/cliente-http/crear", http.StatusSeeOther)
	}
	datos := map[string]string{"nombre": request.FormValue("nombre")}
	jsonValue, _ := json.Marshal(datos)
	client := &http.Client{}
	req, err := http.NewRequest("POST", "https://www.api.tamila.cl/api/categorias", bytes.NewBuffer(jsonValue))
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Set("Authorization", Token)
	reg, _ := client.Do(req)
	defer reg.Body.Close()
	utilidades.CrearMensajesFlash(response, request, "success", "Se creó el registro exitosamente")
	http.Redirect(response, request, "/cliente-http/crear", http.StatusSeeOther)
}
func Cliente_http_editar(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/cliente_http/editar.html", utilidades.Frontend))

	vars := mux.Vars(request)
	client := &http.Client{}
	req, err := http.NewRequest("GET", "https://www.api.tamila.cl/api/categorias/"+vars["id"], nil)
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Set("Authorization", Token)

	reg, err := client.Do(req)
	defer reg.Body.Close()
	body, err := ioutil.ReadAll(reg.Body)
	//fmt.Printf("%s", body)
	//convertimos el resultado a un slice
	datos := modelos.Categoria{}
	errJson := json.Unmarshal(body, &datos)
	if errJson != nil {

	}

	data := map[string]string{

		"id":     vars["id"],
		"nombre": datos.Nombre,
		"slug":   datos.Slug,
	}
	template.Execute(response, data)
}
func Cliente_http_editar_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""
	if len(request.FormValue("nombre")) == 0 {
		mensaje = mensaje + "El campo Nombre está vacío. "
	}
	if mensaje != "" {

	}

	vars := mux.Vars(request)
	client := &http.Client{}
	req, err := http.NewRequest("GET", "https://www.api.tamila.cl/api/categorias/"+vars["id"], nil)
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Set("Authorization", Token)

	reg, err := client.Do(req)
	defer reg.Body.Close()
	body, err := ioutil.ReadAll(reg.Body)
	//fmt.Printf("%s", body)
	//convertimos el resultado a un slice
	datos := modelos.Categoria{}
	errJson := json.Unmarshal(body, &datos)
	if errJson != nil {

	}
	//edito el registro
	datosJson := map[string]string{"nombre": request.FormValue("nombre")}
	jsonValue, _ := json.Marshal(datosJson)
	req2, err2 := http.NewRequest("PUT", "https://www.api.tamila.cl/api/categorias/"+vars["id"], bytes.NewBuffer(jsonValue))
	req2.Header.Set("Authorization", Token)
	if err2 != nil {
		fmt.Println(err2)
	}
	reg2, err3 := client.Do(req2)
	defer reg.Body.Close()
	if err3 != nil {

	}

	defer reg2.Body.Close()

	http.Redirect(response, request, "/cliente-http/editar/"+vars["id"], http.StatusSeeOther)
}
func Cliente_http_eliminar(response http.ResponseWriter, request *http.Request) {
	vars := mux.Vars(request)
	client := &http.Client{}
	req, err := http.NewRequest("GET", "https://www.api.tamila.cl/api/categorias/"+vars["id"], nil)
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Set("Authorization", Token)

	reg, err := client.Do(req)
	defer reg.Body.Close()
	body, err := ioutil.ReadAll(reg.Body)
	//fmt.Printf("%s", body)
	//convertimos el resultado a un slice
	datos := modelos.Categoria{}
	errJson := json.Unmarshal(body, &datos)
	if errJson != nil {

	}
	//edito el registro

	req2, err2 := http.NewRequest("DELETE", "https://www.api.tamila.cl/api/categorias/"+vars["id"], nil)
	req2.Header.Set("Authorization", Token)
	if err2 != nil {
		fmt.Println(err2)
	}
	reg2, err3 := client.Do(req2)
	defer reg.Body.Close()
	if err3 != nil {

	}

	defer reg2.Body.Close()
	http.Redirect(response, request, "/cliente-http", http.StatusSeeOther)
}
