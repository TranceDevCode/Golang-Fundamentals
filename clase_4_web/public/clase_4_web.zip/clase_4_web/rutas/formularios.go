package rutas

import (
	"clase_4_web/utilidades"
	"clase_4_web/validaciones"
	"fmt"
	"html/template"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

func Formularios_get(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/formularios/formularios.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)

}
func Formularios_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""
	if len(request.FormValue("nombre")) == 0 {
		mensaje = mensaje + " El campo nombre está vacío."
	}
	if len(request.FormValue("correo")) == 0 {
		mensaje = mensaje + " El campo E-Mail está vacío."
	}
	if validaciones.Regex_correo.FindStringSubmatch(request.FormValue("correo")) == nil {
		mensaje = mensaje + " . El E-Mail ingresado no es válido "
	}
	if validaciones.ValidarPassword(request.FormValue("password")) == false {
		mensaje = mensaje + " . La contraseña debe tener al menos 1 número, una mayúscula, y un largo entre 6 y 8 caracteres "
	}
	if mensaje != "" {
		//fmt.Fprintln(response, mensaje)
		//return
		utilidades.CrearMensajesFlash(response, request, "danger", mensaje)
		http.Redirect(response, request, "/formularios", http.StatusSeeOther)
	}
	//p2gHNiENUw
	fmt.Fprintln(response, "Nombre:"+request.FormValue("nombre")+" | E-Mail: "+request.FormValue("correo")+" | Teléfono: "+request.FormValue("telefono")+" | Contraseña: "+request.FormValue("password"))
}
func Formularios_upload(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/formularios/upload.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)

}
func Formularios_upload_post(response http.ResponseWriter, request *http.Request) {
	file, handler, err := request.FormFile("foto")
	if err != nil {
		utilidades.CrearMensajesFlash(response, request, "danger", "Ocurrió un error inesperado 1")
	}
	var extension = strings.Split(handler.Filename, ".")[1]
	time := strings.Split(time.Now().String(), " ")
	foto := string(time[4][6:14]) + "." + extension
	var archivo string = "public/uploads/fotos/" + foto
	f, errCopy := os.OpenFile(archivo, os.O_WRONLY|os.O_CREATE, 0777)
	if errCopy != nil {
		utilidades.CrearMensajesFlash(response, request, "danger", "Ocurrió un error inesperado 2")
	}
	_, errCopiar := io.Copy(f, file)
	if errCopiar != nil {
		utilidades.CrearMensajesFlash(response, request, "danger", "Ocurrió un error inesperado 3")
	}
	//acá lo guardarías en la bd

	//redireccionamos
	utilidades.CrearMensajesFlash(response, request, "success", "Se subió el archivo "+foto+" exitosamente")
	http.Redirect(response, request, "/formularios/upload", http.StatusSeeOther)

}

/*
func Formularios_post(response http.ResponseWriter, request *http.Request) {
	fmt.Fprintln(response, "Nombre:"+request.FormValue("nombre")+" | E-Mail: "+request.FormValue("correo")+" | Teléfono: "+request.FormValue("telefono")+" | Contraseña: "+request.FormValue("password"))
}

*/
