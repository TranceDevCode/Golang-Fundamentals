package rutas

import (
	"clase_4_web/conectar"
	"clase_4_web/modelos"
	"clase_4_web/utilidades"
	"clase_4_web/validaciones"
	"fmt"
	"html/template"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func Mysql_listar(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/mysql/home.html", utilidades.Frontend))

	//conexión a la bd
	conectar.Conectar()
	sql := "SELECT id, nombre, correo, telefono FROM clientes order by id desc"
	clientes := modelos.Clientes{}
	datos, err := conectar.Db.Query(sql)
	if err != nil {
		fmt.Println(err)
	}
	defer conectar.CerrarConexion()
	for datos.Next() {
		dato := modelos.Cliente{}
		datos.Scan(&dato.Id, &dato.Nombre, &dato.Correo, &dato.Telefono)
		clientes = append(clientes, dato)
	}
	//retorno

	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := modelos.ClienteHttp{
		Css:     css_sesion,
		Mensaje: css_mensaje,
		Datos:   clientes,
	}
	template.Execute(response, data)

}
func Mysql_crear(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/mysql/crear.html", utilidades.Frontend))
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	data := map[string]string{

		"css":     css_sesion,
		"mensaje": css_mensaje,
	}
	template.Execute(response, data)
}
func Mysql_crear_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""
	if len(request.FormValue("nombre")) == 0 {
		mensaje = mensaje + "El campo Nombre está vacío  "
	}
	if len(request.FormValue("correo")) == 0 {
		mensaje = mensaje + " . El campo E-Mail está vacío "
	}

	if validaciones.Regex_correo.FindStringSubmatch(request.FormValue("correo")) == nil {
		mensaje = mensaje + " . El E-Mail ingresado no es válido "
	}
	if len(request.FormValue("telefono")) == 0 {
		mensaje = mensaje + " . El campo Teléfono está vacío "
	}
	if mensaje != "" {
		utilidades.CrearMensajesFlash(response, request, "danger", mensaje)
		http.Redirect(response, request, "/mysql/crear", http.StatusSeeOther)
		return
	}
	conectar.Conectar()
	sql := "INSERT into clientes values(null, ?, ? , ? );"
	_, err := conectar.Db.Exec(sql, request.FormValue("nombre"), request.FormValue("correo"), request.FormValue("telefono"))
	if err != nil {
		fmt.Fprintln(response, err)
	}

	utilidades.CrearMensajesFlash(response, request, "success", "Se creó el registro exitosamente")
	http.Redirect(response, request, "/mysql/crear", http.StatusSeeOther)
}
func Mysql_editar(response http.ResponseWriter, request *http.Request) {
	template := template.Must(template.ParseFiles("templates/mysql/editar.html", utilidades.Frontend))

	conectar.Conectar()
	sql := "SELECT id, nombre, correo, telefono FROM clientes where id=?"
	//clientes := modelos.Clientes{}

	vars := mux.Vars(request)
	datos, err := conectar.Db.Query(sql, vars["id"])
	if err != nil {
		fmt.Println(err)
	}
	defer conectar.CerrarConexion()
	var dato modelos.Cliente
	for datos.Next() {

		err := datos.Scan(&dato.Id, &dato.Nombre, &dato.Correo, &dato.Telefono)

		if err != nil {
			log.Fatal(err)
		}

	}
	css_sesion, css_mensaje := utilidades.RetornarMensajesFlash(response, request)
	clientehttp := modelos.ClienteHttp2{
		Css:     css_sesion,
		Mensaje: css_mensaje,
		Datos:   dato,
	}
	template.Execute(response, clientehttp)
}
func Mysql_editar_post(response http.ResponseWriter, request *http.Request) {
	mensaje := ""
	vars := mux.Vars(request)
	if len(request.FormValue("nombre")) == 0 {
		mensaje = mensaje + "El campo Nombre está vacío  "
	}
	if len(request.FormValue("correo")) == 0 {
		mensaje = mensaje + " . El campo E-Mail está vacío "
	}

	if validaciones.Regex_correo.FindStringSubmatch(request.FormValue("correo")) == nil {
		mensaje = mensaje + " . El E-Mail ingresado no es válido "
	}
	if len(request.FormValue("telefono")) == 0 {
		mensaje = mensaje + " . El campo Teléfono está vacío "
	}

	if mensaje != "" {
		utilidades.CrearMensajesFlash(response, request, "danger", mensaje)
		http.Redirect(response, request, "/mysql/editar/"+vars["id"], http.StatusSeeOther)
	}
	conectar.Conectar()

	sql := "update clientes set nombre=?, correo=?, telefono=? where id=?;"
	_, err := conectar.Db.Exec(sql, request.FormValue("nombre"), request.FormValue("correo"), request.FormValue("telefono"), vars["id"])
	if err != nil {
		fmt.Println(err)
	}
	utilidades.CrearMensajesFlash(response, request, "success", "Se modificó el registro exitosamente")
	http.Redirect(response, request, "/mysql/editar/"+vars["id"], http.StatusSeeOther)
}

func Mysql_eliminar(response http.ResponseWriter, request *http.Request) {
	vars := mux.Vars(request)
	conectar.Conectar()
	sql := "delete from clientes where id=?;"
	_, err := conectar.Db.Exec(sql, vars["id"])
	if err != nil {
		fmt.Fprintln(response, err)
	}
	utilidades.CrearMensajesFlash(response, request, "success", "Se eliminó el registro exitosamente")

	http.Redirect(response, request, "/mysql", http.StatusSeeOther)
}
